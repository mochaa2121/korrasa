// Kurrasa — shared site-wide behavior. No external analytics/trackers loaded by default
// (see cookie consent gate below). Page-specific logic (product rendering, checkout) lives
// in an inline script at the bottom of product.html / checkout.html.

(function () {
  "use strict";

  /* ---------- Mobile nav ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", function () {
      var open = links.classList.toggle("nav-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    // Close the mobile menu after choosing a link, and on outside click.
    links.addEventListener("click", function (e) {
      if (e.target.tagName === "A") {
        links.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("click", function (e) {
      if (links.classList.contains("nav-open") && !links.contains(e.target) && e.target !== toggle) {
        links.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ---------- Sticky header shadow on scroll (rAF-coalesced) ---------- */
  var header = document.querySelector("header.site-header");
  if (header) {
    var ticking = false;
    window.addEventListener(
      "scroll",
      function () {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(function () {
          header.classList.toggle("is-scrolled", window.scrollY > 8);
          ticking = false;
        });
      },
      { passive: true }
    );
  }

  /* Scroll-scrubbed notebook, gooey text, stats, and section reveals. */
  var notebookStage = document.querySelector('.notebook-stage');
  var notebook = document.getElementById('hero-notebook');
  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var scrollBar = document.querySelector('.site-scroll-progress');
  var scrollFrame = 0;
  var scrub = function () {
    if (scrollFrame) return;
    scrollFrame = window.requestAnimationFrame(function () {
      scrollFrame = 0;
      var scrollTop = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
      var pageHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - window.innerHeight;
      if (scrollBar) scrollBar.style.setProperty('--page-progress', pageHeight > 0 ? (scrollTop / pageHeight).toFixed(3) : '0');
      if (notebookStage && notebook && !reducedMotion) {
        var rect = notebookStage.getBoundingClientRect();
        var stageStart = rect.top + scrollTop;
        var start = stageStart - window.innerHeight * .25;
        var travel = Math.max(notebookStage.offsetHeight, window.innerHeight * .72) + window.innerHeight * .25;
        var progress = Math.max(0, Math.min(1, (scrollTop - start) / travel));
        notebookStage.classList.toggle('is-open', progress > .16);
        notebook.style.setProperty('--scroll-progress', progress.toFixed(3));
        notebook.style.setProperty('--open-angle', (-42 * progress).toFixed(2) + 'deg');
        notebook.style.transform = 'rotateX(' + (7 - progress * 5) + 'deg) rotateY(' + (-8 + progress * 5) + 'deg) rotateZ(' + (2 - progress * 3) + 'deg) translateY(' + (progress * -6) + 'px)';
      }
    });
  };
  window.addEventListener('scroll', scrub, {passive:true});
  window.addEventListener('resize', scrub, {passive:true});
  scrub();

  document.querySelectorAll('[data-gooey-text]').forEach(function (el) {
    el.classList.add('gooey-target');
  });
  var gooeyObserver = 'IntersectionObserver' in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) { entry.target.classList.add('is-gooey-visible'); gooeyObserver.unobserve(entry.target); }
    });
  }, {threshold:.2}) : null;
  document.querySelectorAll('.gooey-target').forEach(function (el) {
    if (reducedMotion) el.classList.add('is-gooey-visible');
    else if (gooeyObserver) gooeyObserver.observe(el);
    else el.classList.add('is-gooey-visible');
  });

  document.querySelectorAll('[data-counter]').forEach(function (el) {
    var target = Number(el.getAttribute('data-counter')) || 0;
    var suffix = el.getAttribute('data-counter-suffix') || '';
    var render = function (value) { el.textContent = Math.round(value) + suffix; };
    var animate = function () {
      if (reducedMotion) { render(target); return; }
      var started = performance.now();
      var duration = 900;
      var tick = function (now) {
        var progress = Math.min(1, (now - started) / duration);
        render(target * (1 - Math.pow(1 - progress, 3)));
        if (progress < 1) window.requestAnimationFrame(tick);
      };
      window.requestAnimationFrame(tick);
    };
    if ('IntersectionObserver' in window && !reducedMotion) {
      var counterObserver = new IntersectionObserver(function (entries) { if (entries[0].isIntersecting) { animate(); counterObserver.disconnect(); } }, {threshold:.5});
      counterObserver.observe(el);
    } else animate();
  });

  var marquee = document.querySelector('[data-magnetic-marquee]');
  if (marquee && !reducedMotion) {
    marquee.addEventListener('pointermove', function (e) {
      var rect = marquee.getBoundingClientRect();
      var x = ((e.clientX - rect.left) / rect.width) * 100;
      var y = ((e.clientY - rect.top) / rect.height) * 100;
      marquee.style.setProperty('--spot-x', x + '%');
      marquee.style.setProperty('--spot-y', y + '%');
      marquee.style.setProperty('--marquee-shift', ((x - 50) * .14).toFixed(1) + 'px');
    });
    marquee.addEventListener('pointerleave', function () { marquee.style.setProperty('--marquee-shift', '0px'); });
  }

  document.querySelectorAll('.btn, .nav-cta').forEach(function (button) {
    if (reducedMotion) return;
    button.addEventListener('pointermove', function (e) {
      var rect = button.getBoundingClientRect();
      button.style.setProperty('--btn-x', (((e.clientX - rect.left) / rect.width - .5) * 4).toFixed(2) + 'px');
      button.style.setProperty('--btn-y', (((e.clientY - rect.top) / rect.height - .5) * 4).toFixed(2) + 'px');
    });
    button.addEventListener('pointerleave', function () { button.style.setProperty('--btn-x', '0px'); button.style.setProperty('--btn-y', '0px'); });
  });
  var reveals = document.querySelectorAll('.scroll-reveal');
  if ('IntersectionObserver' in window) {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); revealObserver.unobserve(entry.target); } });
    }, {threshold:.16});
    reveals.forEach(function (el) { revealObserver.observe(el); });
  } else { reveals.forEach(function (el) { el.classList.add('is-visible'); }); }

  /* ---------- FAQ: keep only one open at a time ---------- */
  var faqDetails = document.querySelectorAll(".faq details");
  faqDetails.forEach(function (d) {
    d.addEventListener("toggle", function () {
      if (d.open) {
        faqDetails.forEach(function (other) {
          if (other !== d) other.open = false;
        });
      }
    });
  });

  /* ---------- Cookie consent (only non-essential cookies gated) ---------- */
  var CONSENT_KEY = "kurrasa_cookie_consent"; // 'accepted' | 'rejected'
  var banner = document.getElementById("cookie-banner");
  if (banner) {
    var existing = localStorage.getItem(CONSENT_KEY);
    if (!existing) {
      banner.classList.add("show");
    }
    var acceptBtn = document.getElementById("cookie-accept");
    var rejectBtn = document.getElementById("cookie-reject");
    function hideBanner() { banner.classList.remove("show"); }
    if (acceptBtn) acceptBtn.addEventListener("click", function () {
      localStorage.setItem(CONSENT_KEY, "accepted");
      hideBanner();
      // Only load analytics AFTER explicit consent, and only here.
      // loadAnalytics();
    });
    if (rejectBtn) rejectBtn.addEventListener("click", function () {
      localStorage.setItem(CONSENT_KEY, "rejected");
      hideBanner();
    });
  }

  /* ---------- Simple client-side form validation (generic forms) ---------- */
  document.querySelectorAll("form[data-validate]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      var valid = true;
      form.querySelectorAll("[required]").forEach(function (field) {
        var errorEl = document.getElementById(field.id + "-error");
        if (!field.value.trim()) {
          valid = false;
          field.setAttribute("aria-invalid", "true");
          if (errorEl) errorEl.textContent = "This field is required.";
        } else {
          field.removeAttribute("aria-invalid");
          if (errorEl) errorEl.textContent = "";
        }
      });
      if (!valid) e.preventDefault();
    });
  });
})();
