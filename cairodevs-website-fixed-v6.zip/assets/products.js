// Kurrasa — shared product catalog. Single source of truth for product.html and checkout.html,
// so every product page and checkout page reflects the same name, price, and file.

var KURRASA_PRODUCTS = {
  "cv-kit": {
    id: "cv-kit",
    name: "CV Template Kit",
    price: 120,
    summary: "Two CV layouts formatted for entry-level job applications in Egypt.",
    description: "Two CV layouts \u2014 one page and two pages \u2014 built to match what recruiters on local job boards scan for first: clear section order, consistent spacing, and no graphics that break applicant tracking systems.",
    included: [
      "A one-page layout, for internships and first applications",
      "A two-page layout, for when you have more experience to show",
      "Placeholder text in every section showing what to write and how"
    ],
    format: "One Word document (.docx). Edit it directly in Word, or upload it to Google Docs \u2014 both keep the formatting.",
    file: "CV_Template_Kit.docx",
    fileLabel: "CV_Template_Kit.docx",
    thumb: "cv"
  },
  "thesis-pack": {
    id: "thesis-pack",
    name: "Thesis Formatting Pack",
    price: 180,
    summary: "A pre-formatted Word template matching common faculty submission requirements.",
    description: "A Word template with a cover page, an auto-updating table of contents, consistent chapter heading styles, and a reference list you can adapt to your department's citation style.",
    included: [
      "Cover page layout for university, title, supervisor, and date",
      "Table of contents that updates automatically from your chapter headings",
      "Chapter structure from Abstract through Appendices, with formatting notes in every section",
      "A one-page formatting guide showing the heading styles in use"
    ],
    format: "One Word document (.docx) with heading styles and page numbers already set up.",
    file: "Thesis_Formatting_Pack.docx",
    fileLabel: "Thesis_Formatting_Pack.docx",
    thumb: "thesis"
  },
  "study-planner": {
    id: "study-planner",
    name: "Semester Study Planner",
    price: 90,
    summary: "An editable Excel planner for tracking lectures, deadlines, and exam revision.",
    description: "An Excel workbook with a weekly class schedule, an assignment tracker with automatic day-countdowns, and an exam revision planner \u2014 built for tracking a full semester.",
    included: [
      "Weekly class & study schedule grid",
      "Assignment tracker with due-date countdown and a status dropdown",
      "Exam revision planner with a countdown to each exam"
    ],
    format: "One Excel workbook (.xlsx). Also opens in Google Sheets and LibreOffice Calc.",
    file: "Semester_Study_Planner.xlsx",
    fileLabel: "Semester_Study_Planner.xlsx",
    thumb: "planner"
  },
  "tracker-studio": {
    id: "tracker-studio",
    name: "Cairodevs Tracker Studio",
    price: 149,
    summary: "Five editable Google-Sheets-ready tracker systems for focus, habits, deadlines, money, and semester progress.",
    description: "A connected workbook with Weekly Focus, Habit Loop, Assignment Tracker, Budget Pulse, and Semester Sprint. Mark each item Done or Open, then use the live formulas and charts to see your rhythm.",
    included: [
      "Five organized tracker plans in one workbook",
      "Formula-driven completion, countdowns, variance, and progress bars",
      "Editable charts, including completion and budget doughnut views",
      "Works in Excel and imports cleanly into Google Sheets"
    ],
    format: "One spreadsheet workbook (.xlsx). Upload it to Google Drive and choose Open with Google Sheets.",
    file: "cairodevs-tracker-studio.xlsx",
    fileLabel: "cairodevs-tracker-studio.xlsx",
    thumb: "planner"
  }
};

var KURRASA_THUMBS = {
  cv: '<svg viewBox="0 0 220 140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="CV layout preview"><circle cx="34" cy="32" r="15" fill="none" stroke="#160D12" stroke-width="3"/><path d="M16 58 a18 16 0 0 1 36 0" fill="none" stroke="#160D12" stroke-width="3"/><rect x="60" y="20" width="72" height="9" rx="2" fill="#160D12"/><rect x="60" y="35" width="50" height="7" rx="2" fill="#8A2846"/><line x1="16" y1="72" x2="204" y2="72" stroke="#160D12" stroke-width="1.5"/><rect x="16" y="84" width="188" height="6" rx="2" fill="#E2D3D5"/><rect x="16" y="98" width="188" height="6" rx="2" fill="#E2D3D5"/><rect x="16" y="112" width="130" height="6" rx="2" fill="#E2D3D5"/><rect x="152" y="122" width="52" height="15" rx="7.5" fill="none" stroke="#8A2846" stroke-width="2"/></svg>',
  thesis: '<svg viewBox="0 0 220 140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Thesis document preview"><rect x="34" y="8" width="116" height="124" rx="3" fill="#FFFFFF" stroke="#E2D3D5" stroke-width="2"/><path d="M150 8 L150 30 L128 8 Z" fill="#8A2846"/><rect x="50" y="26" width="84" height="8" rx="2" fill="#160D12"/><rect x="50" y="54" width="42" height="6" fill="#160D12"/><line x1="98" y1="57" x2="118" y2="57" stroke="#E2D3D5" stroke-width="1.5" stroke-dasharray="2 3"/><rect x="122" y="54" width="10" height="6" fill="#8A2846"/><rect x="50" y="70" width="34" height="6" fill="#160D12"/><line x1="90" y1="73" x2="118" y2="73" stroke="#E2D3D5" stroke-width="1.5" stroke-dasharray="2 3"/><rect x="122" y="70" width="10" height="6" fill="#8A2846"/><rect x="50" y="86" width="38" height="6" fill="#160D12"/><line x1="94" y1="89" x2="118" y2="89" stroke="#E2D3D5" stroke-width="1.5" stroke-dasharray="2 3"/><rect x="122" y="86" width="10" height="6" fill="#8A2846"/><rect x="50" y="102" width="30" height="6" fill="#160D12"/><line x1="86" y1="105" x2="118" y2="105" stroke="#E2D3D5" stroke-width="1.5" stroke-dasharray="2 3"/><rect x="122" y="102" width="10" height="6" fill="#8A2846"/></svg>',
  planner: '<svg viewBox="0 0 220 140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Study planner preview"><rect x="30" y="16" width="160" height="108" rx="6" fill="#FFFFFF" stroke="#E2D3D5" stroke-width="2"/><path d="M30 22 a6 6 0 0 1 6-6 h148 a6 6 0 0 1 6 6 v18 h-160 Z" fill="#160D12"/><g fill="none" stroke="#E2D3D5" stroke-width="1.5"><rect x="38" y="52" width="31" height="19"/><rect x="76" y="52" width="31" height="19"/><rect x="114" y="52" width="31" height="19"/><rect x="152" y="52" width="30" height="19"/><rect x="38" y="77" width="31" height="19"/><rect x="76" y="77" width="31" height="19"/><rect x="114" y="77" width="31" height="19"/><rect x="152" y="77" width="30" height="19"/><rect x="38" y="102" width="31" height="19"/><rect x="76" y="102" width="31" height="19"/><rect x="114" y="102" width="31" height="19"/><rect x="152" y="102" width="30" height="19"/></g><circle cx="91.5" cy="61.5" r="4.5" fill="#8A2846"/><circle cx="167" cy="86.5" r="4.5" fill="#8A2846"/><circle cx="53.5" cy="111.5" r="4.5" fill="#8A2846"/></svg>'
};

function kurrasaGetProductId() {
  var params = new URLSearchParams(window.location.search);
  return params.get("id");
}

function kurrasaGetProduct() {
  var id = kurrasaGetProductId();
  return KURRASA_PRODUCTS[id] || null;
}
